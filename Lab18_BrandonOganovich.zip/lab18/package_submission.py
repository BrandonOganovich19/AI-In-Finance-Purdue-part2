"""Build a clean, reproducible submission ZIP without local dependencies or logs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
sys.path.insert(0,str(ROOT))
from test_lab18 import load
from buffett_skill.scripts.edgar import report_text, unsupported_numbers

def build():
    probes={}
    for ticker in ['COST','JPM']:
        result=load(ticker)
        report=report_text(result)
        memo=(ROOT/'memos'/f'{ticker}_memo.md').read_text(encoding='utf-8')
        flags=unsupported_numbers(memo,report)
        assert not flags, f'{ticker} memo contains unsupported numbers'
        probes[ticker]={'checks':result['checks'],'memo_unsupported_numbers':flags}
    tampered=(ROOT/'memos/COST_memo.md').read_text(encoding='utf-8')+'\nThe ROE was 40.0%.\n'
    flags=unsupported_numbers(tampered,report_text(load('COST')))
    assert [f['number'] for f in flags]==['40.0%']
    probes['tampered_COST_memo']={'added_text':'The ROE was 40.0%.','flags':flags}
    installed=PROJECT/'.agents/skills/buffett-business'
    for relative in ['SKILL.md','scripts/edgar.py']:
        assert (installed/relative).read_bytes()==(ROOT/'buffett_skill'/relative).read_bytes(), 'Installed skill drift'
    probes['installed_skill_matches_portable_copy']=True
    probes['skill_discovery']='Observed in the active Codex skills catalog after installation.'
    probes['official_skill_validator']='Skill is valid! (executed November 3, 2026)'
    (ROOT/'evidence/probes.json').write_text(json.dumps(probes,indent=2),encoding='utf-8')
    files=[p for p in ROOT.rglob('*') if p.is_file() and not any(x in p.parts for x in ['__pycache__','live_cache'])
           and p.suffix not in ['.log','.pyc'] and p.name!='submission_manifest.json']
    files += [installed/'SKILL.md',installed/'scripts/edgar.py']
    manifest={'built_utc':datetime.now(timezone.utc).isoformat(),
              'files':[{'path':p.relative_to(PROJECT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                       for p in sorted(files)]}
    manifest_path=ROOT/'evidence/submission_manifest.json'
    manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    files.append(manifest_path)
    output=PROJECT/'Lab18_BrandonOganovich.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path,path.relative_to(PROJECT).as_posix())
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for entry in manifest['files']:
            assert hashlib.sha256(archive.read(entry['path'])).hexdigest()==entry['sha256']
    print(f'Created {output.name}: {len(files)} files, {output.stat().st_size:,} bytes; ZIP CRC and every file hash verified.')

if __name__=='__main__':
    build()
